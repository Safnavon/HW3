package AST;

public enum BINOPS {
    PLUS,
    MINUS,
    TIMES,
    DIVIDE,
    LTE,
    LT,
    GT,
    GTE,
    EQUAL,
    NEQUAL
}