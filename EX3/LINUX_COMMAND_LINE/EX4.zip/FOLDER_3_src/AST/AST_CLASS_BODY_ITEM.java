package AST;

import src.ClassChecker;
import src.SymbolTable;

public abstract class AST_CLASS_BODY_ITEM extends AST_Node {
	String className;
}