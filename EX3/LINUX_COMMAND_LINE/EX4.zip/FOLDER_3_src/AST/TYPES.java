package AST;

public enum TYPES
{
	INT,
	STRING
}