package AST;

public class AST_EXP_NULL extends AST_EXP{

	@Override
	public AST_TYPE isValid() throws Exception {
		return null;
	}

}
