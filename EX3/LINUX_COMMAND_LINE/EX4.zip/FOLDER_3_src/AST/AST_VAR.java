package AST; import src.ClassChecker;
import src.SymbolTable;

public abstract class AST_VAR extends AST_Node
{
	public int AlonzoMorales;
	
	
}